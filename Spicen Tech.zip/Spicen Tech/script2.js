const SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbwWvc5eMKjVtKLlHOo0UZxpv6yVCp-bKSw85A4W5vb7o9iN4kNVY_Iz0xZx1FpuBua4/exec';

document.addEventListener('DOMContentLoaded', () => {
    // --- REGISTRATION LOGIC ---
    const regForm = document.getElementById('registerForm');
    if (regForm) {
        regForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const btn = regForm.querySelector('button');
            btn.innerText = "CREATING ACCOUNT...";

            const formData = new FormData();
            formData.append('action', 'register');
            formData.append('name', document.getElementById('regName').value);
            formData.append('email', document.getElementById('regEmail').value);
            formData.append('password', document.getElementById('regPass').value);

            fetch(SCRIPT_URL, { method: 'POST', body: formData })
                .then(() => {
                    alert("Registration Successful! Please login.");
                    window.location.href = 'login.html';
                });
        });
    }

    // --- LOGIN LOGIC ---
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const btn = loginForm.querySelector('button');
            btn.innerText = "VERIFYING...";

            const formData = new FormData();
            formData.append('action', 'login');
            formData.append('email', document.getElementById('loginEmail').value);
            formData.append('password', document.getElementById('loginPass').value);

            // Inside your loginForm event listener
fetch(SCRIPT_URL, { method: 'POST', body: formData })
    .then(res => res.text())
    .then(response => {
        if (response !== "Invalid") {
            // 1. Save the ClientID to localStorage
            localStorage.setItem('spicenClientID', response);
            // 2. Immediately redirect to the homepage
            window.location.replace('index.html'); 
        } else {
            alert("Invalid credentials. Please try again.");
        }
    });
        });
    }

    // --- INDEX.HTML DATA FETCH ---
    if (window.location.pathname.includes('index.html') || window.location.pathname === '/') {
        const clientID = localStorage.getItem('spicenClientID');
        if (clientID) {
            console.log("Welcome back, Client:", clientID);
            // Here you can call a function to fetch their website records from the sheet
        }
    }
});
// --- AUTHENTICATION GUARD ---
(function() {
    const publicPages = ['login.html', 'register.html'];
    const currentPage = window.location.pathname.split("/").pop();
    const clientID = localStorage.getItem('spicenClientID');

    // If there is no session and the user is NOT already on login/register, redirect them.
    if (!clientID && !publicPages.includes(currentPage) && currentPage !== "") {
        window.location.href = 'login.html';
    }
})();